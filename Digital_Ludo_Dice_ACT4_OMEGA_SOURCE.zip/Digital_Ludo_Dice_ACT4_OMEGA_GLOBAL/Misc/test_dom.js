/* Uji DOM: halaman dimuat lengkap di jsdom, tanpa error JS kritis. */
const { JSDOM } = require('jsdom');
const fs = require('fs'), path = require('path');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'Html/index.html'), 'utf8');

const dom = new JSDOM(html, {
  runScripts: 'outside-only',
  url: 'http://localhost/Html/index.html',
  resources: undefined,
  pretendToBeVisual: true
});
const { window } = dom;
const errors = [];

// audio + firebase stubs (WebView tidak menyediakan di jsdom)
window.Audio = function () { return { play(){ return Promise.resolve(); }, pause(){}, load(){}, volume:1, currentTime:0, duration:0, preload:'', src:'' }; };
try { window.localStorage.clear(); } catch (e) {}
window.Firebase = function () { return { on(){}, set(){}, child(){ return { set(){}, on(){} }; } }; };
window.app = undefined;
window.alert = () => {};
window.console.error = (...a) => errors.push(a.join(' '));

function run(file) {
  const code = fs.readFileSync(path.join(root, 'Html', file), 'utf8');
  window.eval(code);
}
try {
  ['config.js','app.js','zf.js','libs/jquery-3.6.0.min.js','libs/firebase.js','engine.js','ui.js'].forEach(f => {
    try { run(f); } catch (e) { errors.push(f + ': ' + e.message); }
  });
} catch (e) { errors.push('boot: ' + e.message); }

const mustExist = ['s-splash','s-main','c-game','c-setting','ember1','ember2','cupsound'];
const missing = mustExist.filter(id => !window.document.getElementById(id));

const checks = [
  ['config.js memuat urlDB', !!(window.DLD_CONFIG && window.DLD_CONFIG.urlDB)],
  ['shim app siap', typeof window.app === 'object' && typeof window.app.LoadBoolean === 'function'],
  ['media player bisa dibuat', (() => { try { return !!window.app.CreateMediaPlayer().SetFile('../Snd/kocok.ogg'); } catch(e){ return false; } })()],
  ['elemen inti ada', missing.length === 0],
  ['handler back tersedia', typeof window.AndroidBack === 'function'],
  ['tanpa error JS kritis', errors.length === 0]
];
let pass = 0;
checks.forEach(([n, ok]) => { console.log((ok?'  PASS  ':'  FAIL  ') + n); if (ok) pass++; });
if (missing.length) console.log('  elemen hilang:', missing);
if (errors.length) console.log('  error:', errors.slice(0,5));
console.log('\nHASIL DOM: ' + pass + ' lulus, ' + (checks.length-pass) + ' gagal');
