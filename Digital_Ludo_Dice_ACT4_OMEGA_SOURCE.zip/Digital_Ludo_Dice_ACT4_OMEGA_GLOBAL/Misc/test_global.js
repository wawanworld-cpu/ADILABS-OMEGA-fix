const fs = require('fs'), vm = require('vm');

// ---------- stub DOM minimal ----------
function makeEl(id) {
  return { id, style:{}, ontouchstart:null,
    classList:{add(){},remove(){}}, addEventListener(){},
    getBoundingClientRect(){ return {left:0,top:0,width:1080,height:1800,right:1080,bottom:1800}; } };
}
function JQ(){
  const h = { length:0, eq:()=>JQ(), get:()=>({src:''}), is:()=>false,
              offset:()=>({top:0,left:0}), css:()=>JQ(), removeClass:()=>JQ(), addClass:()=>JQ(),
              on:()=>JQ(), show:()=>JQ(), hide:()=>JQ(), animate:()=>JQ(), prop:()=>JQ() };
  return new Proxy(h, { get(t,k){ return (k in t) ? t[k] : (()=>JQ()); }, apply(){ return JQ(); } });
}

const listeners = {};
const ctx = {
  console,
  setTimeout: (fn)=>{ fn(); return 0; },           // timer langsung
  setInterval: ()=>0, clearTimeout: ()=>{}, clearInterval: ()=>{},
  Date, Math, JSON, parseInt, parseFloat, isFinite, String, Number, Array, Object,
  $: JQ, jQuery: JQ,
  elById: makeEl,
  app: {
    LoadBoolean:(k,d)=>d, LoadNumber:(k,d)=>d, SaveBoolean(){}, SaveNumber(){},
    SetOrientation(){}, SetScreenMode(){}, SetDebugEnabled(){}, EnableBackKey(){},
    CopyFile:()=>{}, Exit(){}, ShowPopup(){}, CreateMediaPlayer:()=>({Play(){},Pause(){},Stop(){},SeekTo(){},SetVolume(){}}),
    GetAppPath:()=>'', IsConnected:()=>true, GetSDKVersion:()=>30
  },
  soundKocok:{Play(){},Pause(){},Stop(){},SeekTo(){},PlayLoop(){}},
  soundLempar:{Play(){},Pause(){},Stop(){},SeekTo(){}},
  soundInEmber:{Play(){},Pause(){},Stop(){},SeekTo(){}},
  Firebase: function(){ return {on(){}, set(){}, update(){}, child:()=>({}) }; },
  navigator:{share:null}, location:{href:''}, alert:()=>{}
};
ctx.window = ctx;
ctx.window.innerWidth = 1080; ctx.window.innerHeight = 1800;
ctx.window.screen = {width:1080, height:1800};
ctx.window.addEventListener = (t,fn,o)=>{ (listeners[t]=listeners[t]||[]).push(fn); };
ctx.document = {
  readyState:'complete',
  getElementById: makeEl,
  addEventListener(){}
};
ctx.global = ctx;

vm.createContext(ctx);
vm.runInContext(fs.readFileSync('Html/zf.js','utf8'), ctx, {filename:'zf.js'});
vm.runInContext(fs.readFileSync('Html/engine.js','utf8'), ctx, {filename:'engine.js'});

// ---------- state permainan ----------
ctx.stat='besar'; ctx.preRes=[]; ctx.prevRes=[1,1,1]; ctx.round=0; ctx.diceType=1;
ctx.penambah=3; ctx.diceNum=3; ctx.bankResults=[3,1,3,4,2,6,1,1,4,5,6,6,3,4,6,6,1]; ctx.indexResult=0;

let calls = 0;
const origSetResults = ctx.setResults;
ctx.setResults = function(){ calls++; return; };
ctx.moveTo = function(){};

function fire(type, x, y){
  const ev = { type, touchend:null, touches:[{clientX:x, clientY:y}], clientX:x, clientY:y,
               cancelable:true, _pd:false, preventDefault(){ this._pd = true; } };
  (listeners[type]||[]).forEach(fn=>fn(ev));
  return ev;
}

const points = [
  ['pojok kiri atas',   30,   60],
  ['tengah atas',      540,   60],
  ['pojok kanan atas', 1050,  60],
  ['tengah layar',     540,  900],
  ['pojok kiri bawah',  30, 1740],
  ['tengah bawah',     540, 1740],
  ['pojok kanan bawah',1050, 1740],
  ['area papan',       540,  600],
  ['area baki',        540, 1200],
  ['background kosong',200,  300]
];

let pass=0, fail=0;
console.log('== UJI GLOBAL TOUCH (10 titik, satu aktivasi per sentuhan) ==');
for (const [name,x,y] of points){
  ctx.kocok();                       // gerbang terbuka (real path, timer sinkron)
  const armedBefore = ctx._adiArmed;
  const before = calls;
  const ev = fire('touchstart', x, y);
  const delta = calls - before;
  const okRange = Array.isArray(ctx.preRes) && ctx.preRes.length===3 && ctx.preRes.every(v=>v>=4&&v<=6);
  const ok = armedBefore && delta===1 && okRange && ev._pd;
  if (ok) pass++; else fail++;
  console.log(`  ${ok?'PASS':'FAIL'}  ${name.padEnd(18)} x=${String(x).padStart(4)} y=${String(y).padStart(4)} | aktivasi=${delta} | hasil=${JSON.stringify(ctx.preRes)}`);
}

// ---------- anti double trigger ----------
ctx.kocok();
let before = calls;
fire('touchstart', 540, 900);
const afterTouch = calls - before;
fire('mousedown', 540, 900);            // mouse sintetis setelah sentuhan
const afterSynthetic = calls - before;
console.log('== ANTI DOUBLE TRIGGER ==');
console.log(`  ${afterTouch===1 && afterSynthetic===1 ? 'PASS':'FAIL'}  touch=1 lalu mousedown sintetis diabaikan (total aktivasi=${afterSynthetic})`);
afterSynthetic===1 ? pass++ : fail++;

// ---------- gerbang tertutup: UI tidak terganggu ----------
before = calls;
fire('touchstart', 540, 900);
const closedDelta = calls - before;
console.log('== GERBANG TERTUTUP (tombol/UI tidak terpicu) ==');
console.log(`  ${closedDelta===0 ? 'PASS':'FAIL'}  sentuhan saat tidak bersiap = ${closedDelta} aktivasi`);
closedDelta===0 ? pass++ : fail++;

console.log(`\nHASIL: ${pass} lulus, ${fail} gagal`);
process.exit(fail ? 1 : 0);
