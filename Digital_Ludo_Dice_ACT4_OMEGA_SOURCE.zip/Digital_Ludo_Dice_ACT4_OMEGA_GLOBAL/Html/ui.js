/* ============================================================
   ui.js — lapisan tampilan. TIDAK mengubah logika engine.
   Tugas: transisi splash/menu, jembatan tombol ke fungsi engine,
   dan sinkronisasi sakelar suara. Semua fungsi permainan tetap
   milik engine.js (SOURCE B).
   ============================================================ */

var _hideGame = hideGame;
hideGame = function () { _hideGame(); tampilMenu(); };

var _hideSetting = hideSetting;
hideSetting = function () { _hideSetting(); tampilMenu(); };

function tampilMenu() {
  var m = elById('s-main');
  if (m) { m.classList.remove('out'); }
}

function sembunyikanMenu() {
  var m = elById('s-main');
  if (m) { m.classList.add('out'); }
}

/* dipanggil tombol One..Six di menu */
function pilihDadu(n) {
  sembunyikanMenu();
  setTimeout(function () { setDice(n); }, 120);
}

/* sakelar suara di halaman setelan */
function ubahSuara(v) {
  try { $('#cupsound').prop('checked', !!v); } catch (e) {}
  try { toggleSound(!!v); } catch (e) {}
}

function bagikan() {
  try {
    if (window.AndroidApp && window.AndroidApp.share) { window.AndroidApp.share(); return; }
  } catch (e) {}
  if (navigator.share) {
    navigator.share({ title: 'Digital Ludo Dice', text: 'Roll the dice. Win the game.' });
  }
}

/* urutan buka aplikasi: splash -> menu */
(function () {
  function mulai() {
    var sp = elById('s-splash');
    if (sp) { sp.classList.add('out'); setTimeout(function () { sp.style.display = 'none'; }, 360); }
    setTimeout(tampilMenu, 160);
    setTimeout(function () {
      try {
        var on = $('#cupsound').is(':checked');
        var sw = elById('switch-sound');
        if (sw) { sw.checked = on; }
      } catch (e) {}
    }, 60);
  }
  window.addEventListener('load', function () { setTimeout(mulai, 1500); });
})();


/* ============================================================
   Jembatan tombol Back Android (dipanggil launcher DroidScript).
   Urutan: tutup setelan -> tutup permainan -> keluar.
   ============================================================ */
window.AndroidBack = function () {
  try {
    var st = document.getElementById('c-setting');
    if (st && st.style && st.style.display !== 'none' && !st.classList.contains('hide')) {
      if (typeof hideSetting === 'function') { hideSetting(); return 'handled'; }
    }
  } catch (e) {}
  try {
    var gm = document.getElementById('c-game');
    if (gm && gm.style && gm.style.display !== 'none') {
      if (typeof hideGame === 'function') { hideGame(); return 'handled'; }
    }
  } catch (e) {}
  return 'exit';
};
