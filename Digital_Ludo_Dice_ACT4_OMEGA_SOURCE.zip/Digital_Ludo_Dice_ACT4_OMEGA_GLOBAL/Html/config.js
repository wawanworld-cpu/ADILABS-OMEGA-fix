/* ============================================================
   config.js — pusat konfigurasi (jangan taruh logika di sini)
   Ubah nilai di bawah untuk memindahkan endpoint, mengatur
   jalur aset, atau menyalakan mode debug tanpa menyentuh engine.
   ============================================================ */
window.DLD_CONFIG = {
  /* Endpoint Firebase Realtime Database (struktur data tidak diubah). */
  urlDB: "https://astar-7131c-default-rtdb.firebaseio.com/b/",

  /* Jalur aset relatif terhadap Html/index.html */
  imgDir: "../Img/",
  origDir: "../OrigImg/",
  sndDir: "../Snd/",
  fontDir: "../Fonts/",

  /* Perilaku aplikasi */
  appName: "Digital Ludo Dice",
  version: "1.0.0-ds",
  debug: false
};
