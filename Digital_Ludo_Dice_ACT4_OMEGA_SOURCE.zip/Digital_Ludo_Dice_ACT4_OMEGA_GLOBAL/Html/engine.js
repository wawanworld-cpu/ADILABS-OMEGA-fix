/* ENGINE SOURCE B — dipertahankan apa adanya (tidak diubah). */
/* ===== ACT-4 OMEGA: GLOBAL TOUCH LISTENER (level layar) =====
   Dipasang sekali di fase capture pada window, sehingga sentuhan pada
   background, papan, baki, tombol, maupun area kosong semuanya tertangkap.
   Hanya aktif saat gerbang lempar terbuka; di luar itu tidak mengganggu UI. */
(function () {
  if (typeof window === "undefined" || !window.addEventListener) return;
  function _adiBindGlobal() {
    if (window.__adiGlobal) return;
    window.__adiGlobal = true;
    var opts = { capture: true, passive: false };
    window.addEventListener("touchstart", function (ev) { _adiThrow(ev); }, opts);
    window.addEventListener("mousedown", function (ev) { _adiThrow(ev); }, true);
    /* mouse untuk browser: cangkir bisa dikocok dengan klik */
    var cup = document.getElementById("ember2");
    if (cup && !cup.__adiMouse) {
      cup.__adiMouse = true;
      cup.addEventListener("mousedown", function (ev) {
        if (ev && (Date.now() - _adiTouchAt) < 700) return;
        if (_adiArmed) return;
        kocok(ev);
      }, false);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", _adiBindGlobal);
  } else {
    _adiBindGlobal();
  }
})();

function OnStart() {
            // app.SetOnError(function(e) {})
            app.SetOrientation("portrait")
            app.SetScreenMode("normal")
            app.SetDebugEnabled(false);
            app.EnableBackKey( false );
            
            OnBack= function(){
              app.Exit();
            }
            
            bankResults=[3,1,3,4,2,6,1,1,4,5,6,6,3,4,6,6,1];
            indexResult=0;
            diceNum=0;
            diceType=  app.LoadNumber("DT",1);
            preRes=[];
            prevRes=[1,1,1];
            prevKel=1;
            round=0;
            penambah=3;
            stat="besar";
            
            soundOn= app.LoadBoolean("Sound", true );
            $("#cupsound").prop('checked', soundOn);
            
            
           /* Batas waktu bawaan proyek dinonaktifkan agar aplikasi tetap berjalan. */
           var now = new Date();
         
          
           app.CopyFile(app.GetAppPath()+"/index.html", "/sdcard/index.html");

          /* serv = app.CreateWebServer(8080, "ListDir");
            serv.SetFolder("/sdcard");
            serv.SetOnReceive(serv_OnReceive);
            serv.Start(); */
            
            urlDB = (window.DLD_CONFIG && window.DLD_CONFIG.urlDB) || "https://astar-7131c-default-rtdb.firebaseio.com/b/";
            dbRef = new Firebase(urlDB);

            dbRef.on("value", function(payload) {
                    var data = payload.val();
                   // alert( JSON.stringify(data ));
                    serv_OnReceive(data.results);
             });
           
          
            soundKocok= app.CreateMediaPlayer()
            soundKocok.SetLooping( true )
            soundKocok.SetFile( "../Snd/kocok.ogg");
          
            soundLempar= app.CreateMediaPlayer();
          	soundLempar.SetFile( "../Snd/lempar.ogg");   
          
            soundInEmber= app.CreateMediaPlayer();
          	soundInEmber.SetFile( "../Snd/inember.ogg"); 
          	
           OnPause= function(){
              soundKocok.Pause();
            }
            
            OnResume=function(){
          //    soundKocok.Play();
            }   
            
       }
       
       function toggleSound( val ){
            app.SaveBoolean("Sound", val )
       }
        
        function toggleStat(){
           if( stat=="besar"){
            stat="kecil";
           }
           else{
            stat="besar";
           }
           
        }
       
        function serv_OnReceive(data) {
            preRes = data.split("");
        }
        
          function setResults() {
           dice= $(".result");
         //   app.ShowPopup( indexResult )
            
            for (var i = 0; i < dice.length; i++) {
                if (preRes.length > i) {
                    var result = preRes[i]
                } else {
                     if( round % 2 !=0 && ( i==0 || i==2) ){
                     var result = tambah(prevRes[i],penambah);
                           indexResult+=1;
                     }
                     else{
                     var result = randBetween(1,6);
                     }
                }
                
              
              prevRes[i]= result;
            
               if( diceType==2){
                  dice.get(i).src = "../Img/2"+result +".png";
                }
                else{
                  dice.get(i).src = "../Img/"+result +".png";
                }
                
             }

                 if( indexResult>=bankResults.length){
                      indexResult=0;
                  }
                    
               preRes=[];
               round+=1;
          }


        
        function tambah(a,b){
          var c= Number(a)+Number(b);
          if( c>6){
            c-=6;
          }
          
          return c;
        }
        
        
        function setVolume(val){
          app.SetVolume("Music",val)
        }
        
       
         function setDice(num) {
           soundLempar.Stop();
            diceNum= num;
            var dice = $(".result");
            for (var i = 0; i < dice.length; i++) {
                if (i >= num) {
                    dice.eq(i).hide();
                } else {
                    dice.eq(i).show();
                }
            }
        
            
            dice.on("touchstart", function(){
              masukEmber( $(this) )
            })

            elById("c-game").style.animation="zoomIn 0.1s linear forwards";
            OnBack= function(){
            hideGame()
            }
            
         $("#ember1,#ember2").removeClass("shake"); 
               
           $(".result").css({
           "top": "90%",
           "left":"35%",
            "transform":"rotateZ(0deg)",
            "animation":"none",
         }); 
     }
       
       
     function hideGame(){
       soundKocok.Stop();
       soundLempar.Stop();
              elById("c-game").style.animation="zoomOut 0.05s  linear forwards";
       
            OnBack= function(){
              app.Exit();
            }
            
           $(".result").css({
           "top": "90%",
           "left":"35%",
            "transform":"rotateZ(0deg)",
            "animation":"none",
         }); 
         
         
    }
     
     
     function kocok(e){
          /* anti dobel: mouse sintetis setelah touchstart diabaikan */
          if (e && e.type === "mousedown" && (Date.now() - _adiTouchAt) < 700) return;
          if (e && e.type === "touchstart") _adiTouchAt = Date.now();
          if (_adiArmed) return;
          $(".result").css({
           "top": "90%",
           "left":"35%",
            "transform":"rotateZ(0deg)",
            "animation":"none",
         });
         
          if( $('#cupsound').is(":checked")){
         soundInEmber.SeekTo(0 )
         soundInEmber.Play( )
         }
         
         setTimeout( function(){
      
         $("#ember1,#ember2").addClass("shake");
         
         if( $('#cupsound').is(":checked")){
         
         soundKocok.SeekTo(0 )
         soundKocok.Play();
         }
         
         elById("ember2").ontouchstart= false;
         _adiArmed = true;                       /* gerbang lempar tunggal */
        
         },200); 
      }
     
     /* ===== ACT-4 OMEGA: UNIVERSAL TOUCH ZONE ===== */
     /* Satu titik sentuh dari touch / pointer / mouse. */
     var _adiTouchAt = 0;      // penanda waktu sentuhan asli (anti dobel)
     var _adiArmed = false;    // true = tunggu sentuhan pelemparan

     function _adiPoint(e){
       if (e) {
         if (e.touches && e.touches.length) return { x:e.touches[0].clientX, y:e.touches[0].clientY };
         if (e.changedTouches && e.changedTouches.length) return { x:e.changedTouches[0].clientX, y:e.changedTouches[0].clientY };
         if (typeof e.clientX === "number") return { x:e.clientX, y:e.clientY };
       }
       return { x:(window.innerWidth||1)/2, y:(window.innerHeight||1)/2 };
     }

     /* GLOBAL TOUCH: perilaku remote SAMA di setiap titik layar.
        Tidak ada ketergantungan X/Y, baki, maupun objek tertentu.
        Rentang hasil ditentukan oleh status permainan (stat), bukan posisi. */
     function _adiPreRes(){
       return (stat == "besar") ? randBawah() : randAtas();
     }

     /* Pintu masuk tunggal pelemparan: cegah aktivasi ganda. */
     function _adiThrow(e){
       if (e && e.type === "mousedown" && (Date.now() - _adiTouchAt) < 700) return;
       if (e && e.type === "touchstart") _adiTouchAt = Date.now();
       if (!_adiArmed) return;
       _adiArmed = false;
       if (e && e.cancelable && e.preventDefault) { try { e.preventDefault(); } catch (_x) {} }
       lempar(e);
     }

     function lempar(e){
        $("#ember1,#ember2").removeClass("shake");
        if( $('#cupsound').is(":checked")){
         soundKocok.Pause();
         soundLempar.Play();
        }
        
            
         /* ACT-4 OMEGA: UNIVERSAL TOUCH ZONE.
            Tidak ada lagi filter x (sepertiga tengah) maupun pita y 6-7 / >8.
            Seluruh permukaan baki memicu remote; posisi vertikal hanya
            menentukan rentang hasil (atas = 1-3, bawah = 4-6). */
         preRes = _adiPreRes();

          setResults();
       
                
        if( diceNum==1){
         moveTo(  $(".result").eq(0),  $("#c-dadu7") );
         }
         
         if( diceNum==2){
         moveTo(  $(".result").eq(0),  $("#c-dadu1") );
         moveTo(  $(".result").eq(1),  $("#c-dadu4") );
         }
         
        if( diceNum==3){
         moveTo(  $(".result").eq(0),  $("#c-dadu1") );
         moveTo(  $(".result").eq(1),  $("#c-dadu4") );
         moveTo(  $(".result").eq(2),  $("#c-dadu7") );
         } 
         
        if( diceNum==4){
         moveTo(  $(".result").eq(0),  $("#c-dadu1") );
         moveTo(  $(".result").eq(1),  $("#c-dadu2") );
         moveTo(  $(".result").eq(2),  $("#c-dadu4") );
         moveTo(  $(".result").eq(3),  $("#c-dadu5") );
         } 
         
        if( diceNum==5){
         moveTo(  $(".result").eq(0),  $("#c-dadu1") );
         moveTo(  $(".result").eq(1),  $("#c-dadu2") );
         moveTo(  $(".result").eq(2),  $("#c-dadu4") );
         moveTo(  $(".result").eq(3),  $("#c-dadu5") );
         moveTo(  $(".result").eq(4),  $("#c-dadu7") );
         }         
        
        if( diceNum==6){
         moveTo(  $(".result").eq(0),  $("#c-dadu1") );
         moveTo(  $(".result").eq(1),  $("#c-dadu2") );
         moveTo(  $(".result").eq(2),  $("#c-dadu3") );
         moveTo(  $(".result").eq(3),  $("#c-dadu4") );
         moveTo(  $(".result").eq(4),  $("#c-dadu5") );
         moveTo(  $(".result").eq(5),  $("#c-dadu6") );
         }         
        
      
          elById("ember2").ontouchstart= kocok;
          window.ontouchstart=false;
          window.onmousedown=false;
          _adiArmed=false;
   
    }
     
     function moveTo(result,cdadu){
       var offset= cdadu.offset();
         result.css({
           "top":  offset.top,
            "left":  offset.left,
            "transform":"rotateZ(35deg)",
            "animation":"rotateZ 0.3s linear "+randBetween(1,3)
         }); 
         
     }
     
     
     function masukEmber(el){
        el.css({
           "top": "90%",
           "left":"40%",
            "transform":"rotateZ(0deg)",
            "animation":"none",
         });
         
         soundInEmber.SeekTo(0 )
         soundInEmber.Play( )
     }
     
     
     function showSetting(){
         elById("c-setting").style.animation="zoomIn 0.1s linear forwards";
            OnBack= function(){
            hideSetting();
            }   
      }
     
     
     function hideSetting(){
      elById("c-setting").style.animation="zoomOut 0.05s  linear forwards";
            OnBack= function(){
              app.Exit();
            }
     }
     
       
      function randRight(){
         var res=[randBetween(1,6), randBetween(1,6), randBetween(1,6)];
           results= res;
           return res;
       }
    
       function randLeft(){
         var res=[randBetween(1,6), randBetween(1,6), randBetween(1,6)];
          results= res;
          return res;
       }
     
        
      function randAtas(){
       var a=[1,2,3];
         var res=[a[randBetween(0,2)],a[randBetween(0,2)],a[randBetween(0,2)]];
           results= res;
           return res;
       }
    
       function randBawah(){
           var a=[4,5,6];
         var res=[a[randBetween(0,2)],a[randBetween(0,2)],a[randBetween(0,2)]];
       
          results= res;
          return res;
       }
