/* ============================================================
   app.js — jembatan API (browser shim + DroidScript aware)
   Bila dijalankan di DroidScript, objek `app` native TIDAK ditimpa.
   Bila dijalankan di WebView/browser biasa, shim ini menyediakan
   localStorage, Audio, dan no-op untuk API khusus Android.
   ============================================================ */
(function () {
  var hasNative = (typeof window.app === "object" && window.app !== null
                   && typeof window.app.LoadBoolean === "function");
  if (hasNative) { return; }   /* DroidScript asli — pakai API-nya */

  var cfg = window.DLD_CONFIG || {};
  var sndDir = cfg.sndDir || "../Snd/";
  var vol = 1.0;

  function ls(k, v) {
    try {
      if (v === undefined) return window.localStorage.getItem(k);
      window.localStorage.setItem(k, v);
    } catch (e) { return null; }
  }

  function mediaPlayer(file) {
    var a = new Audio();
    a.preload = "auto";
    if (file) a.src = sndDir + file;
    var api = {
      SetFile: function (f) { a.src = (/^(\/|\.\/|\.\.\/|https?:)/.test(f) ? f : sndDir + f); try { a.load(); } catch (e) {} return api; },
      SetLooping: function (b) { a.loop = !!b; return api; },
      SetVolume: function (v) { a.volume = Math.max(0, Math.min(1, Number(v) || 0)); return api; },
      Play: function () { try { a.volume = vol; a.play().catch(function () {}); } catch (e) {} return api; },
      Pause: function () { try { a.pause(); } catch (e) {} return api; },
      Stop: function () { try { a.pause(); a.currentTime = 0; } catch (e) {} return api; },
      SeekTo: function (ms) { try { a.currentTime = (Number(ms) || 0) / 1000; } catch (e) {} return api; },
      IsPlaying: function () { return !a.paused; },
      GetDuration: function () { return (a.duration || 0) * 1000; }
    };
    return api;
  }

  window.app = {
    SetOrientation: function () {}, SetScreenMode: function () {},
    SetDebugEnabled: function () {}, SetOnError: function () {},
    EnableBackKey: function () {}, Debug: function (m) { try { console.log("DLD: " + m); } catch (e) {} },
    Exit: function () {
      try { if (window.AndroidApp && window.AndroidApp.exit) { window.AndroidApp.exit(); return; } } catch (e) {}
      try { window.close(); } catch (e) {}
    },
    ShowPopup: function (msg) { try { alert(msg); } catch (e) {} },
    GetAppPath: function () { return ""; },
    CopyFile: function () { return true; },
    CreateWebServer: function () { return { SetFolder: function () {}, SetOnReceive: function () {}, Start: function () {}, GetPort: function () { return 0; } }; },
    SetVolume: function (v) { vol = Math.max(0, Math.min(1, Number(v))); },
    GetVolume: function () { return vol; },
    LoadBoolean: function (k, d) { var v = ls("b_" + k); if (v === null || v === undefined) return d === undefined ? false : !!d; return v === "1"; },
    SaveBoolean: function (k, v) { ls("b_" + k, v ? "1" : "0"); },
    LoadNumber: function (k, d) { var v = ls("n_" + k); if (v === null || v === undefined || v === "") return d === undefined ? 0 : Number(d); var n = Number(v); return isNaN(n) ? (d === undefined ? 0 : Number(d)) : n; },
    SaveNumber: function (k, v) { ls("n_" + k, String(v)); },
    LoadText: function (k, d) { var v = ls("t_" + k); return v === null || v === undefined ? (d === undefined ? "" : d) : v; },
    SaveText: function (k, v) { ls("t_" + k, String(v)); },
    CreateMediaPlayer: function (file) { return mediaPlayer(file); }
  };
})();
