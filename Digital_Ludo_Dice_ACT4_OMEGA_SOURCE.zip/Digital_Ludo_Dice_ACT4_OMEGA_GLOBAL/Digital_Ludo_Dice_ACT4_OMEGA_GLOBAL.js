/* ============================================================
   Digital Ludo Dice — DroidScript launcher (WebView container)
   Target API : DroidScript 2.x — app.CreateWebView / app.ZipFolder
   Struktur   : proyek ini memuat seluruh aset secara lokal.
   ============================================================ */

var web = null;      /* objek WebView                */
var lay = null;      /* layout layar penuh           */
var pageReady = false; /* halaman web sudah dimuat?  */
var entryFile = "Html/index.html";

/* ---------- util ---------- */
function dsLog(msg) {
  try { app.Debug("DLD: " + msg); } catch (e) {}
}

function entryUrl() {
  var base = "";
  try { base = app.GetAppPath(); } catch (e) { base = ""; }
  if (!base) base = "/sdcard/DroidScript/DigitalLudoDice_DHARMA_OMEGA";
  /* GetAppPath() -> folder proyek, atau folder assets saat jadi APK */
  return "file://" + base + "/" + entryFile;
}

/* ---------- lifecycle ---------- */
function OnStart() {
  try { app.SetDebugEnabled(false); } catch (e) {}
  try { app.SetOnError(OnAppError); } catch (e) {}
  try { app.SetOrientation("Portrait"); } catch (e) {}
  try { app.SetScreenMode("Full"); } catch (e) {}
  try { app.EnableBackKey(false); } catch (e) {}  /* agar OnBack dipanggil */

  lay = app.CreateLayout("linear", "FillXY,VCenter");
  lay.SetBackColor("#0f1014");

  /* FillX/Y + IgnoreErrors agar aset lokal tetap dimuat walau ada
     permintaan eksternal yang gagal (mis. Firebase offline). */
  web = app.CreateWebView(1, 1, "FillX/Y,IgnoreErrors,NoScrollBars,Progress");
  web.SetBackColor("#0f1014");

  try { web.SetOnProgress(web_OnProgress); } catch (e) {}
  try { web.SetOnConsole(web_OnConsole); } catch (e) {}
  try { web.SetOnError(web_OnError); } catch (e) {}

  lay.AddChild(web);
  app.AddLayout(lay);

  web.LoadUrl(entryUrl());
  dsLog("memuat " + entryUrl());
}

function OnBack() {
  if (!web || !pageReady) { app.Exit(); return; }
  /* halaman menentukan sendiri: tutup popup/menu dulu, atau keluar */
  var ok = false;
  try {
    web.Execute("(window.AndroidBack?window.AndroidBack():'exit')", function (res) {
      ok = true;
      if (String(res) === "exit") app.Exit();
    });
  } catch (e) {}
  /* fallback bila callback tak didukung versi DroidScript ini */
  setTimeout(function () { if (!ok) app.Exit(); }, 400);
}

function OnConfig() {
  /* dipanggil saat orientasi/konfigurasi berubah */
  try { if (web) web.Resize(); } catch (e) {}
}

function OnPause() { try { if (web) web.Execute("window.AndroidPause&&window.AndroidPause()"); } catch (e) {} }
function OnResume() { try { if (web) web.Execute("window.AndroidResume&&window.AndroidResume()"); } catch (e) {} }

/* ---------- event webview ---------- */
function web_OnProgress(p) {
  if (p >= 1) { pageReady = true; dsLog("halaman siap"); }
}

function web_OnConsole(msg) {
  var text = (msg && msg.message) ? msg.message : String(msg);
  if (msg && msg.level) text = msg.level + ": " + text;
  dsLog("[console] " + text);
}

function web_OnError(msg) {
  dsLog("[error] " + msg);
  /* jangan ganggu permainan; cukup catat untuk diagnosa */
}

function OnAppError(msg) {
  dsLog("[app-error] " + msg);
  try { app.ShowPopup("Terjadi kesalahan: " + msg); } catch (e) {}
}
