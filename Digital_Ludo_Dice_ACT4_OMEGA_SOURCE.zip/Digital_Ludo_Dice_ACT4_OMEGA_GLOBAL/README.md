# Digital Ludo Dice — ACT-4 OMEGA (DroidScript Project)

Proyek DroidScript berbasis WebView. Seluruh UI, logika, dan aset berada di dalam proyek
(tidak memuat halaman eksternal), sehingga bisa dibuka, diedit, dijalankan, dan dibangun
ulang langsung dari aplikasi DroidScript di Android.

## Struktur

    Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL/
    ├── Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL.js     launcher DroidScript (WebView + Back + error)
    ├── Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL.html   pratinjau di browser / editor
    ├── build.json                                 konfigurasi build APK
    ├── Html/
    │   ├── index.html      struktur UI
    │   ├── style.css       tampilan (tidak diubah dari desain asli)
    │   ├── config.js       konfigurasi terpusat (Firebase, opsi)
    │   ├── app.js          jembatan API (browser shim / DroidScript aware)
    │   ├── zf.js           util angka (randBetween dll)
    │   ├── engine.js       game engine + GLOBAL TOUCH ACT-4 OMEGA
    │   ├── ui.js           transisi UI + hook tombol Back
    │   ├── libs/           jQuery, Firebase, interact, animate.css
    │   └── font-awesome/
    ├── Img/        gambar dadu & UI
    ├── OrigImg/    ikon & latar asli
    ├── Snd/        kocok.ogg, lempar.ogg, inember.ogg
    ├── Fonts/      f1.TTF
    └── Misc/       skrip uji (test_global.js, test_dom.js)

## Cara memakai di DroidScript

1. Salin folder proyek ini ke /sdcard/DroidScript/ (atau impor file .SPK).
2. Buka DroidScript, pilih proyek Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL.
3. Tekan Run untuk menjalankan; WebView memuat file lokal Html/index.html.
4. Edit bebas: tampilan di Html/style.css, logika di Html/engine.js, konfigurasi di Html/config.js.

## Membuat ulang SPK

Di DroidScript, jalankan dari console:

    app.ZipFolder("/sdcard/DroidScript/Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL",
                  "/sdcard/DroidScript/SPKs/Digital_Ludo_Dice_ACT4_OMEGA_GLOBAL.SPK",
                  "spk");

## Build APK

Menu proyek → Build → isi nama paket, versi, dan izin (INTERNET, ACCESS_NETWORK_STATE,
WAKE_LOCK). Nilai awal tersedia di build.json dan boleh disesuaikan saat build.

## Catatan teknis

1. Global touch: satu listener capture di window; satu sentuhan = satu aktivasi; mouse
   sintetis setelah sentuhan diabaikan 700 ms; di luar sesi lempar tidak aktif.
2. Audio memakai HTMLAudioElement (jalur ../Snd/*.ogg), bukan media player native.
3. Firebase memakai endpoint di Html/config.js (urlDB). Ubah di satu tempat itu saja.
4. Tidak ada iklan di proyek ini (APK sumber juga tidak memuat SDK iklan).
5. Bagian yang TIDAK bisa dipulihkan utuh dari APK: kode Java/Kotlin launcher asli
   (hanya tersedia sebagai bytecode). Launcher DroidScript ini adalah rekonstruksi
   fungsional, bukan salinan source asli.
